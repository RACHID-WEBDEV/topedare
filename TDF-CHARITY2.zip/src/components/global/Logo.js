import LogoImage from "../../assets/TDF-Logo-new .png"
export const Logo = () => {
    return (


        <img src={LogoImage} className="h-[65px]" alt="TD-foundation-logo.png" />


    );
};